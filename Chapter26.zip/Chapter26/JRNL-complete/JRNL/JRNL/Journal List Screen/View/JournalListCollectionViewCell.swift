//
//  JournalListTableViewCell.swift
//  JRNL
//
//  Created by myadmin on 22/06/2025.
//

import UIKit

class JournalListCollectionViewCell: UICollectionViewCell {
    
    // MARK: - Properties
    @IBOutlet var photoImageView: UIImageView!
    @IBOutlet var dateLabel: UILabel!
    @IBOutlet var titleLabel: UILabel!

}
