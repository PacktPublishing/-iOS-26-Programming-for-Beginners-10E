//
//  AssistViewController.swift
//  JRNL
//
//  Created by iOS26Programming on 30/07/2025.
//

import UIKit
import FoundationModels

class AssistViewController: UIViewController {
    
    // MARK: - Properties
    @IBOutlet var promptTextField: UITextField!
    @IBOutlet var resultTextView: UITextView!
    
    let session = LanguageModelSession()
    
    // MARK: - View controller lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        promptTextField.delegate = self
        resultTextView.delegate = self
    }
    
    // MARK: - Actions
    @IBAction func generateButtonTapped(_ sender: UIButton) {
        resultTextView.text = "Generating..."
        let prompt = promptTextField.text ?? ""
        Task {
            if isSystemLanguageModelAvailable() {
                resultTextView.text = await generateResult(prompt: prompt)
            } else {
                resultTextView.text = "Sorry, Apple Intelligence is not available on this device"
            }
        }
    }
    
    // MARK: - Private methods
    private func generateResult(prompt: String) async -> String {
        var resultString = ""
        do {
            let result = try await session.respond(to: prompt)
            resultString = result.content
        } catch {
            resultString = "Could not generate content, please try again"
        }
        return resultString
    }
    
    private func isSystemLanguageModelAvailable() -> Bool {
        let model = SystemLanguageModel.default
        switch model.availability {
        case .available:
            return true
        case .unavailable(.deviceNotEligible):
            print("Device not eligible")
            return false
        case .unavailable(.appleIntelligenceNotEnabled):
            print("Apple Intelligence not enabled")
            return false
        case .unavailable(.modelNotReady):
            print("Model not ready")
            return false
        case .unavailable(_):
            print("Model not available for unknown reason")
            return false
        }
    }

}

extension AssistViewController: UITextFieldDelegate, UITextViewDelegate {
    
    // MARK: - UITextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    // MARK: - UITextViewDelegate
    func textView(_ textView: UITextView, shouldChangeTextInRanges ranges: [NSValue], replacementText text: String) -> Bool {
        if (text == "\n") {
            textView.resignFirstResponder()
        }
        return true
    }
    
}
    
