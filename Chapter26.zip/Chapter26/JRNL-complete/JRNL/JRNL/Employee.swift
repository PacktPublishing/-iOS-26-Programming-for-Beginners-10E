//
//  Employee.swift
//  JRNL
//
//  Created by ios25programming on 12/10/2025.
//

import Foundation
// This file contains the definition of the Employee structure, a method that will generate sample data, an EmployeeDatabase structure containing an array of Employee instances and methods to add, delete and find employees in an array.
struct Employee: Identifiable, Codable {
    var id: UUID
    var firstName: String
    var lastName: String
    var email: String
    var position: String
    var department: String
    var hireDate: Date
}

extension Employee {
    static func generateSampleData() -> [Employee] {
        [
            Employee(id: UUID(), firstName: "Tyrion", lastName: "Lannister", email: "tyrion@example.com", position: "King in the North", department: "House of Lannister", hireDate: Date()),
            ]
    }
}

struct EmployeeDatabase {
    private(set) var employees: [Employee] = []
    
    mutating func addEmployee(_ employee: Employee) {
        employees.append(employee)
    }
    
    mutating func deleteEmployee(id: UUID) {
        employees.removeAll { $0.id == id }
    }
    
    func employee(id: UUID) -> Employee? {
        employees.first(where: { $0.id == id })
    }
}
