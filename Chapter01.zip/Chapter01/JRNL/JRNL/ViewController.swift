//
//  ViewController.swift
//  JRNL
//
//  Created by ios25programming on 16/09/2025.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

