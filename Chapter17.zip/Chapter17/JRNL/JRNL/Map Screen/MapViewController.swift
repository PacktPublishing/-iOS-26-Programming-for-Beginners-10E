//
//  MapViewController.swift
//  JRNL
//
//  Created by ios25programming on 01/10/2025.
//

import UIKit
import CoreLocation
import MapKit

class MapViewController: UIViewController {
    // MARK: - Properties
    @IBOutlet var mapView: MKMapView!
    
    private let locationManager = CLLocationManager()
    private var locationTask: Task<Void, Error>?
    private var annotations: [JournalEntry] = []
    private var selectedAnnotation: JournalEntry?

    override func viewDidLoad() {
        super.viewDidLoad()
        fetchUserLocation()
        mapView.delegate = self
        annotations = JournalEntry.createSampleJournalEntryData()
        mapView.addAnnotations(annotations)
    }
    
    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        guard segue.identifier == "showMapDetail" else {
            fatalError("Unexpected segue identifier")
        }
        guard let entryDetailViewController = segue.destination as? JournalEntryDetailViewController else {
            fatalError("Unexpected view controller")
        }
        entryDetailViewController.selectedJournalEntry = selectedAnnotation
    }
}

extension MapViewController {
    // MARK: - CoreLocation
    private func fetchUserLocation() {
        locationManager.requestWhenInUseAuthorization()
        navigationItem.title = "Getting location..."
        locationTask = Task {
            for try await update in CLLocationUpdate.liveUpdates() {
                if let location = update.location {
                    updateMapWithLocation(location)
                } else if update.authorizationDenied {
                    failedToGetLocation(message: "Check Location Services settings for JRNL in Settings > Privacy & Security.")
                } else if update.locationUnavailable {
                    failedToGetLocation(message: "Location Unavailable.")
                }
            }
        }
    }
    
    private func updateMapWithLocation(_ location: CLLocation) {
        let interval = location.timestamp.timeIntervalSinceNow
        if abs(interval) < 30 {
            locationTask?.cancel()
            let lat = location.coordinate.latitude
            let long = location.coordinate.longitude
            navigationItem.title = "Map"
            mapView.region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: lat, longitude: long), span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
        }
    }
    
    private func failedToGetLocation(message: String) {
        locationTask?.cancel()
        navigationItem.title = "Location not found"
        let alertController = UIAlertController(title: "Failed to get location", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default)
        alertController.addAction(okAction)
        present(alertController, animated: true)
    }
}

extension MapViewController: MKMapViewDelegate {
    // MARK: - MKMapViewDelegate
    func mapView(_ mapView: MKMapView, viewFor annotation: any MKAnnotation) -> MKAnnotationView? {
        let identifier = "mapAnnotation"
        guard annotation is JournalEntry else {
            return nil
        }
        if let annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier) {
            annotationView.annotation = annotation
            return annotationView
        } else {
            let annotationView = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: identifier)
            annotationView.canShowCallout = true
            let calloutButton = UIButton(type: .detailDisclosure)
            annotationView.rightCalloutAccessoryView = calloutButton
            return annotationView
        }
    }
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        guard let annotation = mapView.selectedAnnotations.first as? JournalEntry else {
            return
        }
        selectedAnnotation = annotation
        performSegue(withIdentifier: "showMapDetail", sender: self)
    }
}
