//
//  AddJournalEntryViewController.swift
//  JRNL
//
//  Created by ios25programming on 30/09/2025.
//

import UIKit
import CoreLocation
import ImagePlayground

class AddJournalEntryViewController: UIViewController {
    // MARK: - Properties
    @IBOutlet var titleTextField: UITextField!
    @IBOutlet var bodyTextView: UITextView!
    @IBOutlet var photoImageView: UIImageView!
    @IBOutlet var saveButton: UIBarButtonItem!
    @IBOutlet var getLocationSwitch: UISwitch!
    @IBOutlet var getLocationSwitchLabel: UILabel!
    @IBOutlet var ratingView: RatingView!
    
    var newJournalEntry: JournalEntry?
    private let locationManager = CLLocationManager()
    private var locationTask: Task<Void, Error>?
    private var currentLocation: CLLocation?

    override func viewDidLoad() {
        super.viewDidLoad()
        titleTextField.delegate = self
        bodyTextView.delegate = self
        updateSaveButtonState()
        bodyTextView.writingToolsBehavior = .none
        bodyTextView.allowsEditingTextAttributes = true
        bodyTextView.supportsAdaptiveImageGlyph = true
    }
    
    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let title = titleTextField.text ?? ""
        let body = textViewTextToData() ?? Data()
        let photo = photoImageView.image
        let rating = ratingView.rating
        let lat = currentLocation?.coordinate.latitude
        let long = currentLocation?.coordinate.longitude
        newJournalEntry = JournalEntry(rating: rating, title: title, body: body, photo: photo, latitude: lat, longitude: long)
    }
    
    // MARK: - Actions
    @IBAction func locationSwitchValueChanged(_ sender: UISwitch) {
        if getLocationSwitch.isOn {
            getLocationSwitchLabel.text = "Getting location..."
            fetchUserLocation()
        } else {
            currentLocation = nil
            getLocationSwitchLabel.text = "Get location"
            locationTask?.cancel()
        }
    }
    
    @IBAction func getPhoto(_ sender: UITapGestureRecognizer) {
        let imagePickerController = UIImagePickerController()
        imagePickerController.delegate = self
        #if targetEnvironment(simulator)
        imagePickerController.sourceType = .photoLibrary
        #else
        imagePickerController.sourceType = .camera
        imagePickerController.showsCameraControls = true
        #endif
        present(imagePickerController, animated: true)
    }
    
    @IBAction func getAIImage(_ sender: UILongPressGestureRecognizer) {
        if sender.state == .ended {
            photoImageView.image = UIImage(systemName: "progress.indicator")
            guard let prompt = bodyTextView.text else { return }
            Task {
                let generatedImage = try await generateAIImage(prompt: prompt)
                photoImageView.image = generatedImage
            }
        }
    }
    
    // MARK: - Private methods
    private func generateAIImage(prompt: String) async throws -> UIImage? {
        var generatedImage: UIImage?
        do {
            let creator = try await ImageCreator()
            let images = creator.images(for: [.text(prompt)], style: .sketch, limit: 1)
            for try await image in images {
                let anImage = image.cgImage
                generatedImage = UIImage(cgImage: anImage)
            }
        } catch {
            generatedImage = UIImage(systemName: "exclamationmark.triangle")
            print("Image creation error")
        }
        return generatedImage
    }
    
    private func textViewTextToData() -> Data? {
        let textContents = bodyTextView.textStorage
        var rtfData = Data()
        do {
            rtfData = try textContents.data(from: NSRange(location: 0, length: textContents.length), documentAttributes: [.documentType: NSAttributedString.DocumentType.rtfd])
        } catch {
            print("Could not convert to rtfd")
        }
        return rtfData
    }
}

extension AddJournalEntryViewController: UITextFieldDelegate, UITextViewDelegate {
    // MARK: - UITextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        updateSaveButtonState()
    }
    
    // MARK: - UITextViewDelegate
    func textView(_ textView: UITextView, shouldChangeTextInRanges ranges: [NSValue], replacementText text: String) -> Bool {
        if (text == "\n") {
            textView.resignFirstResponder()
        }
        return true
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        updateSaveButtonState()
    }
    
    func textViewDidChange(_ textView: UITextView) {
        updateSaveButtonState()
    }
    
    // MARK: - Private methods
    private func updateSaveButtonState() {
        let textFieldText = titleTextField.text ?? ""
        let textViewText = bodyTextView.text ?? ""
        let textIsValid = !textFieldText.isEmpty && !textViewText.isEmpty
        if getLocationSwitch.isOn {
            saveButton.isEnabled = textIsValid && currentLocation != nil
        } else {
            saveButton.isEnabled = textIsValid
        }
    }
}

extension AddJournalEntryViewController {
    // MARK: - CoreLocation
    private func fetchUserLocation() {
        locationManager.requestWhenInUseAuthorization()
        locationTask = Task {
            for try await update in
                    CLLocationUpdate.liveUpdates() {
                if let location = update.location {
                    updateCurrentLocation(location)
                } else if update.authorizationDenied {
                    failedToGetLocation(message: "Check Location Services settings for JRNL in Settings > Privacy & Security.")
                } else if update.locationUnavailable {
                    failedToGetLocation(message: "Location Unavailable")
                }
            }
        }
    }
    
    private func updateCurrentLocation(_ location: CLLocation) {
        let interval = location.timestamp.timeIntervalSinceNow
        if abs(interval) < 30 {
            locationTask?.cancel()
            getLocationSwitchLabel.text = "Done"
            let lat = location.coordinate.latitude
            let long = location.coordinate.longitude
            currentLocation = CLLocation(latitude: lat, longitude: long)
            updateSaveButtonState()
        }
    }
    
    private func failedToGetLocation(message: String) {
        locationTask?.cancel()
        getLocationSwitch.setOn(false, animated: true)
        getLocationSwitchLabel.text = "Get location"
        let alertController = UIAlertController(title: "Failed to get location", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default)
        alertController.addAction(okAction)
        present(alertController, animated: true)
    }
}

extension AddJournalEntryViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    // MARK: - UIImagePickerControllerDelegate
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        guard let selectedImage = info[.originalImage] as? UIImage else {
            fatalError("Expected a dictionary containing an image, but was provided the following: \(info)")
        }
        let smallerImage = selectedImage.preparingThumbnail(of: CGSize(width: 300, height: 300))
        photoImageView.image = smallerImage
        dismiss(animated: true)
    }
}

extension AddJournalEntryViewController {
    // MARK: - Writing Tools delegate methods
    func textViewWritingToolsWillBegin(_ textView: UITextView) {
        textView.isEditable = false
    }
    func textViewWritingToolsDidEnd(_ textView: UITextView) {
        textView.isEditable = true
    }
}
