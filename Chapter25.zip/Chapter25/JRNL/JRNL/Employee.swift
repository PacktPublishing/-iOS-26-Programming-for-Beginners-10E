//
//  Employee.swift
//  JRNL
//
//  Created by ios25programming on 09/10/2025.
//

import Foundation

// This file contains the definition of the Employee structure, a method that will generate sample data, an EmployeeDatabase structure containing an array of Employee instances and methods to add, delete and find employees in an array.

struct Employee: Identifiable {
    var id: UUID = UUID()
    var firstName: String
    var lastName: String
    var jobTitle: String
    var salary: Double
}

extension Employee {
    static func sample() -> [Employee] {
        [
            Employee(firstName: "Tyrion", lastName: "Lannister", jobTitle: "King in the North", salary: 1000000000000.00),
            Employee(firstName: "Daenerys", lastName: "Targaryen", jobTitle: "Queen of the Dragons", salary: 1000000000000.00),
            ]
    }
}

struct EmployeeDatabase {
    private(set) var employees: [Employee] = []
    
    mutating func add(_ employee: Employee) {
        employees.append(employee)
    }
    
    mutating func delete(_ employee: Employee) {
        employees.removeAll { $0.id == employee.id }
    }
    
    func find(byId id: UUID) -> Employee? {
        employees.first(where: { $0.id == id })
    }
}
