//
//  Employee.swift
//  JRNL
//
//  Created by iOS26Programming on 24/07/2025.
//

import Foundation

// This file contains the definition of the Employee structure, a method that will generate sample data, an EmployeeDatabase structure containing an array of Employee instances and methods to add, delete and find employees in an array.
struct Employee: Identifiable {
    var id: UUID
    var name: String
    var email: String
    var age: Int
}

extension Employee {
    static func generateSampleData(count: Int = 20) -> [Employee] {
        var employees: [Employee] = []
        for i in 1...count {
            let id = UUID()
            let name = "Employee \(i)"
            let email = "\(name.lowercased()).\(Int.random(in: 1...100))@example.com"
            let age = Int.random(in: 18...65)
            employees.append(Employee(id: id, name: name, email: email, age: age))
        }
        return employees
    }
}

struct EmployeeDatabase {
    private var employees: [Employee] = []
    
    mutating func addEmployee(_ employee: Employee) {
        employees.append(employee)
    }
    
    mutating func deleteEmployee(withId id: UUID) {
        if let index = employees.firstIndex(where: { $0.id == id }) {
            employees.remove(at: index)
        }
    }
    
    func findEmployee(withId id: UUID) -> Employee? {
        return employees.first(where: { $0.id == id })
    }
}
