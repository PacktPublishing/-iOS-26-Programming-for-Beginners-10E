//
//  JournalListTableViewCell.swift
//  JRNL
//
//  Created by ios25programming on 30/09/2025.
//

import UIKit

class JournalListTableViewCell: UITableViewCell {
    // MARK: - Properties
    @IBOutlet var photoImageView: UIImageView!
    @IBOutlet var dateLabel: UILabel!
    @IBOutlet var titleLabel: UILabel!
}
