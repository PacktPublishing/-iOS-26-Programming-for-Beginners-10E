//
//  ViewController.swift
//  BreakfastMaker
//
//  Created by myadmin on 22/06/2025.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var toastLabel: UILabel!
    @IBOutlet var eggLabel: UILabel!
    @IBOutlet var plateAndServeLabel: UILabel!
    @IBOutlet var elapsedTimeLabel: UILabel!
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        let startTime = Date().timeIntervalSince1970
        toastLabel.text = "Making toast..."
        toastLabel.text = makeToast()
        eggLabel.text = "Boiling eggs..."
        eggLabel.text = boilEggs()
        plateAndServeLabel.text = plateAndServe()
        let endTime = Date().timeIntervalSince1970
        elapsedTimeLabel.text = "Elapsed time is \(((endTime - startTime) * 100).rounded() / 100) seconds"
    }
    
    func makeToast() -> String {
        sleep(2)
        return "Toast done"
    }
    
    func boilEggs() -> String {
        sleep(7)
        return "Eggs done"
    }
    
    func plateAndServe() -> String {
        return "Plating and serving done"
    }
    
    @IBAction func testButton(_ sender: UIButton) {
        print("Button tapped")
    }
    
}

