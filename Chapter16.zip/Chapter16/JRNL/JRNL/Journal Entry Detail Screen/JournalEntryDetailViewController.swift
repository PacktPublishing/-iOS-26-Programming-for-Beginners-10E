//
//  JournalEntryDetailViewController.swift
//  JRNL
//
//  Created by ios26programming on 04/11/2025.
//

import UIKit

class JournalEntryDetailViewController: UITableViewController {
    // MARK: - Properties
    @IBOutlet var dateLabel: UILabel!
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var bodyTextView: UITextView!
    @IBOutlet var photoImageView: UIImageView!
    
    var selectedJournalEntry: JournalEntry?

    override func viewDidLoad() {
        super.viewDidLoad()
        dateLabel.text = selectedJournalEntry?.date.formatted(
            .dateTime.day().month(.wide).year()
        )
        titleLabel.text = selectedJournalEntry?.title
        bodyTextView.text = selectedJournalEntry?.body
        photoImageView.image = selectedJournalEntry?.photo
    }

 
}
